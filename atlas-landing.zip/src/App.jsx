
import React, { useMemo, useState } from 'react'
import { MessageSquare, Plane, Hotel, CreditCard, Clock, Shield, MapPin, Star, ChevronRight, Search, Filter, Heart, Instagram, Facebook, Globe } from 'lucide-react'

// ⚠️ Reemplaza por tu número real: 573001112233 (código país + número)
const WHATSAPP_NUMBER = '57XXXXXXXXXX'
const WHATSAPP_MSG = encodeURIComponent('Hola Atlas 👋 Quiero una cotización para mi próximo viaje.')
const WHATSAPP_URL = `https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MSG}&utm_source=web&utm_medium=cta&utm_campaign=generico&utm_content=boton_flotante`

const SOCIALS = {
  instagram: 'https://instagram.com/tu_cuenta',
  facebook: 'https://facebook.com/tu_pagina',
  website: 'https://atlasviajes.co'
}

// Inventario mínimo (mock) — luego conectaremos a RPA/APIs
const INVENTORY = [
  { id:'ctg-boutique-01', place:'Cartagena', country:'Colombia', title:'Boutique amurallada', type:'hotel', rating:4.7, price:520000, img:'https://images.unsplash.com/photo-1587595431973-160d0d94add1?q=80&w=1600&auto=format&fit=crop', tags:['romance','historia'] },
  { id:'sai-all-01', place:'San Andrés', country:'Colombia', title:'All‑inclusive frente al mar', type:'resort', rating:4.5, price:680000, img:'https://images.unsplash.com/photo-1508264165352-258a6ee2a82e?q=80&w=1600&auto=format&fit=crop', tags:['familias','playa'] },
  { id:'mex-riviera-01', place:'Riviera Maya', country:'México', title:'Resort con acceso a cenotes', type:'resort', rating:4.8, price:850000, img:'https://images.unsplash.com/photo-1530789253388-582c481c54b0?q=80&w=1600&auto=format&fit=crop', tags:['todo incluido','aventura'] },
  { id:'eu-roma-01', place:'Roma', country:'Italia', title:'Cerca a Fontana di Trevi', type:'hotel', rating:4.6, price:780000, img:'https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?q=80&w=1600&auto=format&fit=crop', tags:['cultura','parejas'] }
]

function currencyCOP(n){ return n.toLocaleString('es-CO', { style:'currency', currency:'COP', maximumFractionDigits:0 }) }

export default function App(){
  const [query,setQuery] = useState('')
  const [place,setPlace] = useState('')
  const [type,setType] = useState('')
  const [budget,setBudget] = useState('')
  const [sort,setSort] = useState('relevance')
  const [favorites, setFavorites] = useState([])

  const filtered = useMemo(()=>{
    let list = [...INVENTORY]
    const q = query.trim().toLowerCase()
    if(q){
      list = list.filter(x => x.title.toLowerCase().includes(q) || x.place.toLowerCase().includes(q) || x.country.toLowerCase().includes(q) || x.tags.some(t=>t.includes(q)))
    }
    if(place) list = list.filter(x=>x.place===place)
    if(type) list = list.filter(x=>x.type===type)
    if(budget){
      if(budget==='-400k') list = list.filter(x=>x.price<=400000)
      if(budget==='400-800k') list = list.filter(x=>x.price>400000 && x.price<=800000)
      if(budget==='+800k') list = list.filter(x=>x.price>800000)
    }
    if(sort==='price-asc') list.sort((a,b)=>a.price-b.price)
    if(sort==='price-desc') list.sort((a,b)=>b.price-a.price)
    if(sort==='rating-desc') list.sort((a,b)=>b.rating-a.rating)
    return list
  }, [query,place,type,budget,sort])

  const toggleFav = (id)=> setFavorites(curr => curr.includes(id) ? curr.filter(x=>x!==id) : [...curr, id])

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50 to-white text-slate-900">
      {/* NAVBAR */}
      <header className="sticky top-0 z-40 backdrop-blur bg-white/70 border-b">
        <div className="mx-auto max-w-7xl px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-9 w-9 rounded-2xl bg-sky-600 grid place-content-center text-white font-bold">A</div>
            <div className="leading-tight">
              <p className="font-extrabold tracking-tight text-lg">Atlas</p>
              <p className="text-xs text-slate-500">Viajes sin fricción</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#servicios" className="hover:text-sky-700">Servicios</a>
            <a href="#buscador" className="hover:text-sky-700">Buscar</a>
            <a href="#destinos" className="hover:text-sky-700">Destinos</a>
            <a href="#como-funciona" className="hover:text-sky-700">Cómo funciona</a>
            <a href="#opiniones" className="hover:text-sky-700">Opiniones</a>
            <a href="#faq" className="hover:text-sky-700">FAQ</a>
          </nav>
          <div className="flex items-center gap-3">
            <a href={WHATSAPP_URL} target="_blank" rel="noreferrer" className="rounded-2xl h-10 px-5 inline-flex items-center justify-center bg-sky-600 text-white hover:bg-sky-700 transition">
              Habla con Atlas <MessageSquare className="ml-2 h-4 w-4"/>
            </a>
          </div>
        </div>
      </header>

      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="mx-auto max-w-7xl px-4 pt-16 pb-20 grid md:grid-cols-2 gap-10 items-center">
          <div className="space-y-6">
            <span className="inline-block text-xs font-semibold px-3 py-1 rounded-full bg-sky-100 text-sky-700">Nuevo · Automatizado</span>
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight">
              Vacaciones <span className="text-sky-700">sin agentes</span>, hechas para <span className="underline decoration-sky-400 decoration-8 underline-offset-4">clientes exigentes</span>
            </h1>
            <p className="text-lg text-slate-600 max-w-prose">
              Cotiza en minutos, compara tarifas de múltiples proveedores y reserva al instante por WhatsApp. Atlas combina IA + RPA para conseguirte el mejor precio y una experiencia impecable.
            </p>
            <div className="flex flex-wrap gap-3">
              <a href={WHATSAPP_URL} target="_blank" rel="noreferrer" className="h-12 rounded-2xl px-6 text-base inline-flex items-center justify-center bg-sky-600 text-white hover:bg-sky-700 transition">Quiero mi cotización ahora</a>
              <a href="#como-funciona" className="inline-flex items-center gap-1 font-medium hover:gap-2 transition-all">
                Ver cómo funciona <ChevronRight className="h-4 w-4"/>
              </a>
            </div>
            <div className="flex items-center gap-6 text-sm text-slate-500">
              <div className="flex items-center gap-2"><Shield className="h-4 w-4"/> Pagos seguros</div>
              <div className="flex items-center gap-2"><Clock className="h-4 w-4"/> Respuesta en minutos</div>
              <div className="flex items-center gap-2"><Star className="h-4 w-4"/> Servicio premium</div>
            </div>
          </div>
          <div className="relative">
            <div className="aspect-[4/3] w-full rounded-3xl shadow-2xl overflow-hidden ring-1 ring-black/5">
              <img src="https://images.unsplash.com/photo-1502920917128-1aa500764b8a?q=80&w=1800&auto=format&fit=crop" alt="Collage destinos Atlas" className="h-full w-full object-cover"/>
            </div>
            <div className="absolute -bottom-5 -left-5 bg-white rounded-2xl shadow-lg p-3 flex items-center gap-3 ring-1 ring-black/5">
              <Plane className="h-5 w-5"/>
              <p className="text-sm"><span className="font-semibold">+40</span> proveedores conectados</p>
            </div>
          </div>
        </div>
      </section>

      {/* PROOF BAR */}
      <section className="py-6">
        <div className="mx-auto max-w-7xl px-4 grid grid-cols-2 md:grid-cols-4 gap-3 text-sm text-slate-500">
          {['Reservas en minutos','Mejores tarifas globales','Atención 24/7 por WhatsApp','Sin filas ni llamadas'].map((t,i)=>(
            <div key={i} className="rounded-xl bg-white/70 border p-3 text-center">{t}</div>
          ))}
        </div>
      </section>

      {/* MOTOR DE BÚSQUEDA */}
      <section id="buscador" className="py-10 bg-white/70 border-y">
        <div className="mx-auto max-w-7xl px-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <h2 className="text-2xl md:text-3xl font-bold tracking-tight">Busca y explora</h2>
          </div>

          <div className="rounded-2xl border bg-white p-4 md:p-6 shadow-sm mt-4">
            <div className="grid md:grid-cols-5 gap-3">
              <div className="md:col-span-2">
                <div className="flex items-center gap-2 text-sm text-slate-600"><Search className="h-4 w-4"/>Destino, hotel o palabra clave</div>
                <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Ej. Cartagena romántico" className="mt-2 w-full rounded-xl border px-3 h-10"/>
              </div>
              <div>
                <span className="text-sm text-slate-600">Lugar</span>
                <select value={place} onChange={e=>setPlace(e.target.value)} className="mt-2 w-full h-10 rounded-xl border px-3">
                  <option value="">Todos</option>
                  <option>Cartagena</option>
                  <option>San Andrés</option>
                  <option>Riviera Maya</option>
                  <option>Roma</option>
                </select>
              </div>
              <div>
                <span className="text-sm text-slate-600">Tipo</span>
                <select value={type} onChange={e=>setType(e.target.value)} className="mt-2 w-full h-10 rounded-xl border px-3">
                  <option value="">Todos</option>
                  <option value="hotel">Hotel</option>
                  <option value="resort">Resort</option>
                </select>
              </div>
              <div>
                <span className="text-sm text-slate-600">Presupuesto</span>
                <select value={budget} onChange={e=>setBudget(e.target.value)} className="mt-2 w-full h-10 rounded-xl border px-3">
                  <option value="">Todos</option>
                  <option value="-400k">Hasta 400k</option>
                  <option value="400-800k">400k – 800k</option>
                  <option value="+800k">Más de 800k</option>
                </select>
              </div>
            </div>

            <div className="mt-4 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-sm text-slate-600"><Filter className="h-4 w-4"/> {filtered.length} resultados</div>
              <div className="flex items-center gap-2">
                <span className="text-sm text-slate-600">Ordenar</span>
                <select value={sort} onChange={e=>setSort(e.target.value)} className="h-10 rounded-xl border px-3">
                  <option value="relevance">Relevancia</option>
                  <option value="price-asc">Precio ↑</option>
                  <option value="price-desc">Precio ↓</option>
                  <option value="rating-desc">Mejor calificación</option>
                </select>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
              {filtered.map(x=>(
                <div key={x.id} className="rounded-2xl overflow-hidden border group bg-white">
                  <div className="relative aspect-[4/3]">
                    <img src={x.img} alt={x.title} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"/>
                    <button onClick={()=>toggleFav(x.id)} className={`absolute top-2 right-2 rounded-full p-2 backdrop-blur bg-white/70 ring-1 ring-black/10 ${favorites.includes(x.id)?'text-rose-600':'text-slate-700'}`} aria-label="Favorito">
                      <Heart className={`h-4 w-4 ${favorites.includes(x.id)?'fill-current':''}`}/>
                    </button>
                    <div className="absolute bottom-2 left-2">
                      <span className="inline-block text-xs font-semibold px-3 py-1 rounded-full bg-sky-100 text-sky-700">{x.place}</span>
                    </div>
                  </div>
                  <div className="p-4">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="font-semibold leading-tight">{x.title}</p>
                        <p className="text-xs text-slate-500">{x.country} · {x.type}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold">{currencyCOP(x.price)}</p>
                        <p className="text-xs text-slate-500">/ noche</p>
                      </div>
                    </div>
                    <div className="mt-2 flex items-center gap-1 text-amber-500">
                      {Array.from({length:5}).map((_,i)=>(
                        <Star key={i} className={`h-4 w-4 ${i < Math.round(x.rating) ? 'fill-current' : ''}`}/>
                      ))}
                      <span className="text-xs text-slate-500 ml-1">{x.rating.toFixed(1)}</span>
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2 text-xs">
                      {x.tags.map(t=>(<span key={t} className="rounded-full bg-slate-100 px-2 py-1">#{t}</span>))}
                    </div>
                    <div className="mt-4 flex gap-2">
                      <a href={WHATSAPP_URL} target="_blank" rel="noreferrer" className="flex-1 inline-flex items-center justify-center rounded-xl bg-sky-600 text-white h-10 hover:bg-sky-700 transition">Cotizar por WhatsApp</a>
                      <a href="#" className="grid place-items-center rounded-xl border px-3" title="Ver mapa"><MapPin className="h-4 w-4"/></a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* DESTINOS */}
      <section id="destinos" className="py-16 bg-slate-50">
        <div className="mx-auto max-w-7xl px-4">
          <div className="flex items-end justify-between gap-4">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Inspírate</h2>
              <p className="text-slate-600 mt-2">Colección curada de destinos y experiencias reales.</p>
            </div>
            <a href={WHATSAPP_URL} target="_blank" rel="noreferrer" className="hidden md:inline-flex rounded-2xl bg-sky-600 text-white px-4 h-10 items-center">Pide una propuesta</a>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-8">
            {[
              {place:'Cartagena', img:'https://images.unsplash.com/photo-1587595431973-160d0d94add1?q=80&w=1600&auto=format&fit=crop'},
              {place:'San Andrés', img:'https://images.unsplash.com/photo-1508264165352-258a6ee2a82e?q=80&w=1600&auto=format&fit=crop'},
              {place:'México', img:'https://images.unsplash.com/photo-1530789253388-582c481c54b0?q=80&w=1600&auto=format&fit=crop'},
              {place:'Europa', img:'https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?q=80&w=1600&auto=format&fit=crop'}
            ].map(({place,img})=>(
              <div key={place} className="group relative overflow-hidden rounded-2xl aspect-[4/3] ring-1 ring-black/5">
                <img src={img} alt={place} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"/>
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"/>
                <div className="absolute bottom-3 left-3 text-white font-semibold tracking-tight">{place}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CÓMO FUNCIONA */}
      <section id="como-funciona" className="py-16">
        <div className="mx-auto max-w-7xl px-4">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Cómo funciona Atlas</h2>
          <div className="grid md:grid-cols-3 gap-6 mt-8">
            {[
              {step:'1', title:'Escríbenos por WhatsApp', points:['Cuéntanos fechas, destino, presupuesto y viajeros.','Te atendemos en minutos (no bots lentos).']},
              {step:'2', title:'Cotización inteligente', points:['Rastreamos proveedores (Beds, RateHawk, TBO, y más).','Te enviamos 2–3 opciones claras y comparables.']},
              {step:'3', title:'Reserva sin fricción', points:['Link de pago seguro y confirmación inmediata.','Acompañamiento antes, durante y después.']}
            ].map(({step,title,points})=>(
              <div key={step} className="rounded-2xl border bg-white">
                <div className="p-5 font-semibold flex items-center gap-2"><span className="text-xs px-2 py-1 rounded-full bg-slate-100">Paso {step}</span>{title}</div>
                <div className="px-5 pb-5">
                  <ul className="space-y-2 text-slate-600">
                    {points.map(p=>(<li key={p} className="flex gap-2"><span>•</span><span>{p}</span></li>))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* OPINIONES */}
      <section id="opiniones" className="py-16 bg-slate-50">
        <div className="mx-auto max-w-7xl px-4">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Lo que dicen nuestros viajeros</h2>
          <div className="grid md:grid-cols-3 gap-6 mt-8">
            {[1,2,3].map(i=>(
              <div key={i} className="rounded-2xl border bg-white p-6">
                <div className="flex items-center gap-2 text-amber-500" aria-label="5 estrellas">
                  {Array.from({length:5}).map((_,idx)=>(<Star key={idx} className="h-4 w-4 fill-current"/>))}
                </div>
                <p className="mt-3 text-slate-700">“Proceso rapidísimo y súper claro. Encontraron mejor tarifa que en portales. Repetiría sin dudarlo.”</p>
                <p className="mt-3 text-sm text-slate-500">María P. · Medellín</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-16">
        <div className="mx-auto max-w-4xl px-4">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-center">Preguntas frecuentes</h2>
          <div className="mt-8 divide-y rounded-2xl border bg-white">
            {[
              {q:'¿Puedo pagar en COP?', a:'Sí. Aceptamos links de pago, transferencia y otras opciones según tu país.'},
              {q:'¿Emiten factura?', a:'Claro. Enviamos soporte y confirmaciones a tu correo y WhatsApp.'},
              {q:'¿Qué tan rápido responden?', a:'Normalmente en minutos dentro de horario extendido; priorizamos viajes urgentes.'}
            ].map(({q,a})=>(
              <details key={q} className="group p-5">
                <summary className="flex cursor-pointer list-none items-center justify-between font-medium">{q}<ChevronRight className="h-4 w-4 transition-transform group-open:rotate-90"/></summary>
                <p className="mt-3 text-slate-600">{a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="py-16">
        <div className="mx-auto max-w-5xl px-4">
          <div className="rounded-3xl bg-gradient-to-br from-sky-600 to-sky-500 text-white p-10 md:p-14">
            <h3 className="text-2xl md:text-4xl font-bold tracking-tight">Listo para tu próxima escapada</h3>
            <p className="mt-2 text-sky-100">Escríbenos y arma tu viaje ideal hoy mismo.</p>
            <div className="mt-6">
              <a href={WHATSAPP_URL} target="_blank" rel="noreferrer" className="rounded-2xl h-12 px-6 text-base inline-flex items-center justify-center bg-white text-sky-700 hover:bg-slate-100 transition">Chatear por WhatsApp</a>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="py-10 border-t">
        <div className="mx-auto max-w-7xl px-4 grid md:grid-cols-5 gap-8 text-sm">
          <div>
            <div className="flex items-center gap-2">
              <div className="h-9 w-9 rounded-2xl bg-sky-600 grid place-content-center text-white font-bold">A</div>
              <span className="font-bold">Atlas</span>
            </div>
            <p className="mt-3 text-slate-600 max-w-xs">Viajes sin fricción con IA + RPA. Atención premium por WhatsApp.</p>
            <div className="mt-3 flex items-center gap-3">
              <a href={SOCIALS.instagram} target="_blank" rel="noreferrer" title="Instagram" className="rounded-full p-2 border"><Instagram className="h-4 w-4"/></a>
              <a href={SOCIALS.facebook} target="_blank" rel="noreferrer" title="Facebook" className="rounded-full p-2 border"><Facebook className="h-4 w-4"/></a>
              <a href={SOCIALS.website} target="_blank" rel="noreferrer" title="Sitio web" className="rounded-full p-2 border"><Globe className="h-4 w-4"/></a>
            </div>
          </div>
          <div>
            <p className="font-semibold">Explorar</p>
            <ul className="mt-3 space-y-2 text-slate-600">
              <li><a href="#servicios" className="hover:text-sky-700">Servicios</a></li>
              <li><a href="#buscador" className="hover:text-sky-700">Buscador</a></li>
              <li><a href="#destinos" className="hover:text-sky-700">Destinos</a></li>
              <li><a href="#como-funciona" className="hover:text-sky-700">Cómo funciona</a></li>
              <li><a href="#opiniones" className="hover:text-sky-700">Opiniones</a></li>
            </ul>
          </div>
          <div>
            <p className="font-semibold">Contacto</p>
            <ul className="mt-3 space-y-2 text-slate-600">
              <li className="flex items-center gap-2"><MessageSquare className="h-4 w-4"/> WhatsApp</li>
              <li className="flex items-center gap-2"><MapPin className="h-4 w-4"/> Medellín · Colombia</li>
              <li className="flex items-center gap-2"><Shield className="h-4 w-4"/> Políticas & privacidad</li>
            </ul>
          </div>
          <div className="md:col-span-2">
            <p className="font-semibold">Boletín</p>
            <p className="mt-3 text-slate-600">Ofertas y tips de viaje (próximamente).</p>
            <div className="mt-3 flex gap-2">
              <input placeholder="tu@email.com" className="flex-1 h-10 px-3 rounded-xl border"/>
              <button className="rounded-xl bg-sky-600 text-white h-10 px-4">Suscribirme</button>
            </div>
          </div>
        </div>
        <div className="mx-auto max-w-7xl px-4 mt-8 text-xs text-slate-500">© {new Date().getFullYear()} Atlas. Todos los derechos reservados.</div>
      </footer>

      {/* BOTÓN FLOTANTE WHATSAPP */}
      <a href={WHATSAPP_URL} target="_blank" rel="noreferrer" className="fixed bottom-4 right-4 z-50 rounded-full shadow-lg ring-1 ring-black/10 bg-emerald-500 text-white px-4 py-3 flex items-center gap-2 hover:-translate-y-0.5 transition">
        <MessageSquare className="h-4 w-4"/> Chatea ahora
      </a>
    </div>
  )
}
