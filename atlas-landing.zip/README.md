
# Atlas Landing (Vite + React + Tailwind)

1) Instala dependencias:
```
npm install
```
2) Ejecuta en local:
```
npm run dev
```
3) Reemplaza tu número de WhatsApp en `src/App.jsx` (const `WHATSAPP_NUMBER`).

## Deploy en Vercel
- Framework: **Vite + React**
- Build command: `npm run build`
- Output directory: `dist`
